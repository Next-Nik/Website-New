# Mission Wheel Label Placement — 14 May 2026

## What changed

One file: `src/app/components/mission-control/MissionWheel.jsx`

One function modified: `civLabelPosFor(tipX, tipY, angleRad)` — the label
position helper used by both `CivWheel` and `SelfWheel`. One edit fixes
both screenshots (Civ wheel: TECHNOLOGY/SOCIETY/ECONOMY/VISION on the
sides; Self wheel: BODY/FINANCES/INNER GAME/CONNECTION/SPARK on the
sides).

## The rule

Labels are placed with two components:

1. **Radial offset** (outward along the spoke). Was a constant 14px.
   Now scales down to 4px on horizontal spokes. Vertical spokes
   (top, bottom) keep the full 14px outward placement.

2. **Tangential offset** (perpendicular to the spoke). New. Zero on
   vertical spokes. Up to 12px on horizontal spokes, signed so the
   label moves toward the closer pole of the wheel (upper-side labels
   move up, lower-side labels move down — away from both the rail
   AND the spoke node).

Both offsets scale by `|ux|²` (horizontality of the spoke) so diagonals
get partial correction, not a hard cut-off at some arbitrary angle.

## Why these numbers

- `radialBase = 14` — preserved from the prior placement. Top and bottom
  labels are unchanged because their `|ux|²` is ~0.
- `radialPull = 10` — reduces side labels to 4px outward (14 - 10).
  This is conservative enough that labels still sit just past the spoke
  tip rather than landing on the node itself, while clearing the rails
  on a 64px-wide rail column.
- `tangentMax = 12` — about three-quarters of a line height for 17px
  text. Enough to clear the spoke node visibly, not so much that the
  label drifts toward a neighbouring spoke.
- `tangent` is applied **only on the y axis** (`px = 0`). Lateral drift
  on side labels would push them back into the rails — exactly the
  problem we're solving. So tangent motion is constrained to vertical.

If the visual result needs tuning, those two numbers (`radialPull` and
`tangentMax`) are the only knobs.

## Verification

- `civLabelPosFor` is the only function called by both wheels for label
  placement (`CivWheel` calls at line 1063, `SelfWheel` at line 474 —
  both unchanged from the patch).
- Numeric simulation across all 7 Self-wheel spokes confirms:
  - Top spoke (~−90°): tangent = 0, radial = 14. **Unchanged.**
  - Upper-right (~−39°): tangent = −7.3 (moves up), radial = 7.9.
  - Right (~13°): tangent = +11.4 (moves down), radial = 4.5.
  - Lower-right (~64°): tangent = +2.3 (slight down), radial = 12.1.
    (Diagonals near 45°-from-equator only get a small nudge.)
  - Lower-left (~116°): mirror of lower-right.
  - Left (~167°): mirror of right.
  - Upper-left (~219°): mirror of upper-right.
- File parses cleanly with `@babel/parser`.

## What was NOT touched

- The `+4` vertical-centring constant. Unrelated glyph-baseline
  adjustment, kept as-is.
- The anchor logic (`start` / `middle` / `end` based on `ux`). Unchanged.
- The `getTipPos` function. Unchanged. Labels still track their
  spokes through rotation.
- Wheel `RADIUS`. Unchanged. Wheel does not shrink.
- Label `fontSize`, `letterSpacing`, font weights. Unchanged. Text does
  not shrink.
- The rotation-decoupling fix (labels outside the rotating `<g>`).
  Unchanged. Bottom-half labels still read upright.
- Both wheel render trees (CivWheel and SelfWheel). Unchanged except
  for the implicit behavioural change from `civLabelPosFor`.

## Standing 8

```
NextUs_Wheel_Label_Placement_2026-05-14/
├── CHANGES.md (this file)
└── src/
    └── app/
        └── components/
            └── mission-control/
                └── MissionWheel.jsx  (MODIFIED)
```

Deploy by overwriting the one file at its existing path.

## Honest caveat

I can't see the result on your phone. The numbers I picked feel right
based on the dimensions of the SVG and the rail columns, but visual
tuning may still want a tweak. If labels still touch a rail, increase
`radialPull` (try 12 or 14). If labels still touch a node, increase
`tangentMax` (try 14 or 16). Two numbers, one function, no other
files involved.
